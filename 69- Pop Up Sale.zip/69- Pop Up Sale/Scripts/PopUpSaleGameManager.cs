﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PopUpSaleGameManager : MonoBehaviour
{
    public int count = 0;
    public bool isRandom;
    private List<int> VisitedlevelHistory;
    public int StartingLevelIndex;
    public int EndLevelIndex;
    [HideInInspector]
    public int tracker = 0; //using to keep track of ther number of level that have been displayed
                            // controller of the level counter
    private GameManager manager;
    private PopUpSaleLevelController controller;
    public static PopUpSaleGameManager Instance;
    public int audioCounter = 1;
    void Start()
    {
        Instance = this;
        VisitedlevelHistory = new List<int>();
        manager = GetComponent<GameManager>();
        controller = GetComponent<PopUpSaleLevelController>();
        manager.levelCounter = 1;
    }


    public IEnumerator NextRandomLevel(float Sec)
    {
        yield return new WaitForSeconds(Sec);

        bool checker = false;// use if the index is present and it escape the if then it
                             //can come back and choose an other index which enter the if condition and active a certain index

        while (checker == false)
        {
            int index = Random.Range(StartingLevelIndex, EndLevelIndex + 1);
            if (VisitedlevelHistory.Contains(index) == false)
            {
                count++;
                if (manager.Accessibilty)
                {
                    if(count == 1)
                    {
                         AccessibilityManager.instance.root[ AccessibilityManager.Direction.Target] = AccessibilityManager.instance.targetList[index-2].GetComponent<AcessibilityInterface>(); // replacing the target list.
               
                    }
                     Debug.LogError("index ix " + index+" "+ count);
                   
                     switch (index)
                     {
                         case 2:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 6; break;
                         case 3:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 5; break;
                         case 4:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 5; break;
                         case 5:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 5; break;
                         case 6:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 6; break;
                         case 7:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 6; break;
                         case 8:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 6; break;
                         case 9:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 7; break;
                         case 10:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 8; break;
                         case 11:  AccessibilityManager.instance.targetList[index - 2].GetComponent<TargetScript>().timeToWaitToPlayTextATStart = 8; break;
                         default: break;
                     }
                }

                if (manager.Accessibilty)
                  
                    AccessibilityManager.instance.changeTarget(index - 2, true);

                manager.LevelFinish(index);
                VisitedlevelHistory.Add(index);
                manager.levelCounter = index;
                checker = true;



                if (count != 1)
                {
                    PlayerPrefs.SetInt("PROGRESS", PlayerPrefs.GetInt("PROGRESS") + 1);
                    CoreProgressBar.Instance.ProgressInfo();
                }
            }
            else if (VisitedlevelHistory.Count == (EndLevelIndex - StartingLevelIndex) + 1)
            {

                checker = true;
                Debug.Log("in end of random" + manager.levelCounter);

                manager.levelCounter = EndLevelIndex + 1;
                yield return new WaitForSeconds(3f);
                manager.LevelFinish(manager.levelCounter);
            }
        }

    }
}
