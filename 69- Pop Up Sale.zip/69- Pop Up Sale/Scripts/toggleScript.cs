﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class toggleScript : MonoBehaviour
{

    public GameObject inOrder;

    public GameObject random;

    public Sprite On;
    public Sprite Off;
    GameManager manager;
    PopUpSaleGameManager popUpManager;
    // Use this for initialization
    void Start()
    {
        manager = FindObjectOfType<GameManager>();
        popUpManager = FindObjectOfType<PopUpSaleGameManager>();
        random.GetComponent<Image>().sprite = Off;
        inOrder.GetComponent<Image>().sprite = Off;
    }

    public void toggleSwitch(GameObject obj)
    {
		if(EventController.instance != null && !External.Instance.Preview)
			EventController.instance.SetGameType(obj.name);
		
        if (obj.name == inOrder.name)
        {
            popUpManager.isRandom = false;
//            Debug.Log("in order choice has been selected");
            inOrder.GetComponent<Image>().sprite = On;
            random.GetComponent<Image>().sprite = Off;
        }
        else if (obj.name == random.name)
        {
            popUpManager.isRandom = true;
          //  Debug.Log("random choice has been selected");
            random.GetComponent<Image>().sprite = On;
            inOrder.GetComponent<Image>().sprite = Off;
        }
        manager.levelCounter = 14;
        manager.LevelFinish(14);
    }

}
