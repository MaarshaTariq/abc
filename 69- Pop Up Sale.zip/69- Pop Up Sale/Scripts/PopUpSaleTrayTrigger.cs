﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PopUpSaleTrayTrigger : MonoBehaviour
{

    public delegate void MultiDelegate(GameObject obj, GameObject des);
    public MultiDelegate DestinationSelected; // use to tell notify everyone on time of destination selection
    bool CanPutInside = false;
    bool CanPutOutside = false;
    GameObject Temp;
    public string TagName;
    //GameManager Manager;
    bool CanPlayInfoSound = false;
    public DragAndDrop mode;
    public GameObject[] ObjectToAppear;
    private PopUpSaleLevelController controller;
    int Index = 0;
    int trayTowelCounter = 0;
    public GameObject ScoreBoard;
    private GameManager manager;
    private PopUpSaleGameManager bigBoxManager;
    public static PopUpSaleTrayTrigger instanc;

    public int dragcorncounter = 0;
    public bool flag = false;

    // Use this for initialization
    void Start()
    {
        instanc = this;
        manager = GameManager.Instance;
        bigBoxManager = PopUpSaleGameManager.Instance;
        controller = this.transform.parent.GetComponent<PopUpSaleLevelController>();
        if (GameManager.Instance.Accessibilty)      //arslan
        {
            TextToSpeech.ins.infoTextSettings.objectCount = ScoreBoard.transform.childCount;

        }
    }
    void OnEnable()
    {
        if (GameManager.Instance.Accessibilty)      //arslan
        {

            AccessibilityManager.instance.DestinationSelected = check;
        }

    }
    IEnumerator showScore()
    {
        //   Debug.Log("01 ");
        trayTowelCounter++;

        if (trayTowelCounter <= manager.levelCounter - 1)
        {
            //   Debug.Log("02 ");
            for (int i = 0; i < ScoreBoard.transform.childCount; i++)
                if (i == trayTowelCounter - 1)
                {
                    //       Debug.Log("03 ");
                    ScoreBoard.transform.GetChild(i).gameObject.SetActive(true);

                    // play sound of the number
                    manager.PlaySound(trayTowelCounter);

                    if (GameManager.Instance.Accessibilty)      //arslan
                    {
                        yield return new WaitForSeconds(GameManager.Instance.Audio.clip.length);
                        TextToSpeech.ins.infoTextSettings.objectCount = ScoreBoard.transform.childCount - (i + 1);
                        if (trayTowelCounter < manager.levelCounter - 1)
                        {
                            TextToSpeech.ins.PlayRemainingInfoText();

                            CloseCaption.CCManager.instance.CreateCaption
                            (
                                TextToSpeech.ins.GetPlayRemainingInfoText(),
                                TextToSpeech.ins.GetPlayRemainingInfoTextLength()
                            );
                        }
                    }

                    // enable next box collider

                    // if (int.Parse(Temp.name) < 9)
                    // {
                    //     // use to enable collider of next popcorn in series
                    //     //    Debug.Log("enable collider num is " + int.Parse(Temp.name));
                    //     controller.popcorn[int.Parse(Temp.name) + 1].gameObject.GetComponent<BoxCollider>().enabled = true;

                    // }

                }
                else
                    ScoreBoard.transform.GetChild(i).gameObject.SetActive(false);
        }
        if (GameManager.Instance.Accessibilty)
        {
            if (trayTowelCounter == 10)
                AccessibilityManager.instance.GreenBox.SetActive(false);
        }
        FreezeControlsHandler.Instance.FreezeControlls();
        if (trayTowelCounter == manager.levelCounter - 1)
        {
            // play ding sound to tell that the level has completed

            StartCoroutine(afterScore());
        }

    }
    IEnumerator afterScore()
    {

        PlayerPrefs.SetInt("Click", 1);
        print("------------------------------------------------------------------------------------------------------------------------");

        EventController.instance.SetGamePercentage(++EventController.instance.levelCounter);

        if (GameManager.Instance.Accessibilty)      //arslan
        {
            FreezeControlsHandler.Instance.FreezeControlls();
        }
        yield return new WaitForSeconds(manager.Audio.clip.length);

        StartCoroutine(FlashTheNumber(trayTowelCounter - 1));
        manager.PlaySound(41);  //ding sound

        // play last ending line
        yield return new WaitForSeconds(1f);

        manager.levelCounter += 1;
        trayTowelCounter = 0;

        if (bigBoxManager.isRandom)
        {
            // //arslan
            // if(GameManager.Instance.Accessibilty)
            // {
            //     int index = int.Parse(Temp.name) + 1;
            //             PopUpSaleLevelController.instance.popcorn[index].GetComponent<BoxCollider>().enabled = true;
            // }
            if (GameManager.Instance.Accessibilty == false)
            {
                // int index = int.Parse(Temp.name) + 1;
                // PopUpSaleLevelController.instance.popcorn[index].GetComponent<BoxCollider>().enabled = true;
                popCornCollider.ins.ObjectToDrag.transform.position = PopUpSaleLevelController.instance.popcorn[0].transform.position;
                popCornCollider.ins.resetBlockRaycast();
            }


            StartCoroutine(bigBoxManager.NextRandomLevel(2));
            controller.shelfDisabler();
            bigBoxManager.tracker++;

        }
        else
        {


            PlayerPrefs.SetInt("Click", 1);
            Invoke("NextLevel", 2f);

        }

    }

    public void NextLevel()
    {
        PlayerPrefs.SetInt("PROGRESS", PlayerPrefs.GetInt("PROGRESS") + 1);

        if (GameManager.Instance.Accessibilty)
        {
            AccessibilityManager.instance.changeTarget();
            FreezeControlsHandler.Instance.UnFreezeControlls();
        }


        if (manager.levelCounter == bigBoxManager.EndLevelIndex + 1)
        {
            controller.progressBar.SetActive(false);
            controller.infoButton.SetActive(false);
            controller.CloseButton.SetActive(false);

        }
        else
        {
            CoreProgressBar.Instance.ProgressInfo();
            controller.shelfDisabler();
        }

        if (!manager.Accessibilty)
        {
            popCornCollider.ins.ObjectToDrag.transform.position = PopUpSaleLevelController.instance.popcorn[0].transform.position;
            popCornCollider.ins.resetBlockRaycast();
        }
        manager.LevelFinish(manager.levelCounter);


    }
    public IEnumerator FlashTheNumber(int number)
    {
        yield return new WaitForSeconds(0.5f);
        ScoreBoard.transform.GetChild(number).gameObject.SetActive(false);
        yield return new WaitForSeconds(0.5f);
        ScoreBoard.transform.GetChild(number).gameObject.SetActive(true);
        trayTowelCounter = 0;
    }

    // public void MakeObjectGoBack(GameObject[] Object, Transform[] Position, int i)  //make object go back when same type of object is placed when can go back is true
    // {

    //     Object[i].transform.position = Position[i].transform.position;
    //     //Object[i].transform.parent = DragAndDrop.Instance.ObjectOriginalParent.gameObject.transform;
    //     //	Object[i].GetComponent<BoxCollider> ().enabled = false;
    //     // if (int.Parse(Temp.name) > 4)
    //     // {
    //     //     Object[i].transform.SetSiblingIndex(9 - int.Parse(Temp.name));
    //     //     Debug.Log("reseting to orignal index");
    //     // }
    //     // else
    //     // {
    //     //     Object[i].transform.SetSiblingIndex(4 - int.Parse(Temp.name));
    //     //     Debug.Log("reseting to orignal index");
    //     // }

    //     // yield return new WaitForSeconds(0.5f);
    //     //StartCoroutine (EnableCollider (Object[i], 0.5f));
    // }

    void Update()
    {

        //for trigger enter
        if ((Input.GetMouseButtonUp(0) || (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Ended)) && CanPutInside)
        {
            if (Temp.gameObject.tag == TagName)
            {

                //PlaySound (5);
                PlayerPrefs.SetInt("Collected", PlayerPrefs.GetInt("Collected") + 1);

                Temp.gameObject.SetActive(false);
                ObjectToAppear[Index].SetActive(true);
                Index = Index + 1;
                print("going to increase the counter" + Temp.name);
                dragcorncounter++;
                flag = true;

                popCornCollider.ins.resetPopcorn();
                // StartCoroutine(MakeObjectGoBack(mode.ObjectRef, mode.ObjectRefPosition, int.Parse(Temp.gameObject.name)));

                // check if the towel is full accordin to level
                //   Debug.Log("correct");
                StartCoroutine(showScore());

            }


            mode.CanSetParent = false;
            CanPutInside = false;
        }
    }

    void check(GameObject target, GameObject destination)
    {
        FreezeControlsHandler.Instance.FreezeControlls();
        Temp = target;
        if (Temp.gameObject.tag == TagName)
        {
            if (GameManager.Instance.Accessibilty)
            {
                if (trayTowelCounter == 9)
                {
                    if (GameManager.Instance.GameNumber(69))
                    {
                        Image image = AccessibilityManager.instance.GreenBox.GetComponent<Image>();
                        var tempColor = image.color;
                        tempColor.a = 0f;
                        image.color = tempColor;
                    };
                }
            }
            //PlaySound (5);
            PlayerPrefs.SetInt("Collected", PlayerPrefs.GetInt("Collected") + 1);

            Temp.gameObject.SetActive(false);
            ObjectToAppear[Index].SetActive(true);
            Index = Index + 1;
            print("going to increase the counter" + Temp.name);
            dragcorncounter++;
            flag = true;
            EventController.instance.correctOptionSelectionCounter++;

            int index = int.Parse(Temp.name);
            if (int.Parse(Temp.name) < 9)
            {
                index = int.Parse(Temp.name) + 1;
            }
            PopUpSaleLevelController.instance.popcorn[index].GetComponent<BoxCollider>().enabled = true;






            StartCoroutine(showScore());

        }


        mode.CanSetParent = false;
        CanPutInside = false;

    }

    void OnTriggerEnter(Collider Col) //on object enter inside the container
    {
        if (Col.gameObject.tag == "Respawn")
        {
            CanPutInside = true;
            mode.CanSetParent = true;
            Temp = Col.gameObject;

        }

    }

    void OnTriggerExit(Collider Col) //on object exit from the container
    {
        if (Col.gameObject.tag == "Respawn")
        {
            CanPutInside = false;
            mode.CanSetParent = false;

        }
    }


}
