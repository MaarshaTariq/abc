﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PopUpSaleLevelController : MonoBehaviour
{    public GameObject RightTable;
    public GameObject LeftTable;
    public GameObject[] popcorn;
    public static PopUpSaleLevelController instance;
    GameManager manager;
    private int endScreen = 10;
    private Fade fadeInstance;
    public GameObject progressBar;
    public GameObject infoButton;
    public GameObject CloseButton;
    public Text infoText;
    public string text;
    private PopUpSaleGameManager bigBoxManager;
    public bool isEnd = false;

    void Start()
    {
        instance = this;
        PlayerPrefs.SetString("clickable", "false");
        // get instance of the manager
        manager = GameObject.Find("GameManager").GetComponent<GameManager>();

        bigBoxManager = PopUpSaleGameManager.Instance;
        fadeInstance = GetComponent<Fade>();
        //check if the level is intro or game

        if (manager.levelCounter == 14)
        {
            StartCoroutine(into());

        }
        else if (manager.levelCounter == bigBoxManager.EndLevelIndex + 1)
        {


            StartCoroutine(Ending());


        }
        else if (isEnd)
        {
            StartCoroutine(Ending());

        }
        else
        {

            resetTablePopcorn();
            //if its game level

            StartCoroutine(LevelInitializer());
        }


    }
    IEnumerator into()
    {
        manager.PlaySound(32); // let sell popcorn
        yield return new WaitForSeconds(manager.Audio.clip.length);

        manager.PlaySound(33); // sound of noise
        yield return new WaitForSeconds(manager.Audio.clip.length);
        manager.levelCounter = 2;

        // start level 1
        if (PopUpSaleGameManager.Instance.isRandom)
            StartCoroutine(bigBoxManager.NextRandomLevel(2f));
        else
        {
            PlayerPrefs.SetInt("Click", 1);
            Invoke("NextLevel", 2f); // put delay to got o the level 1 after the speach of the introduction
        }

    }
    IEnumerator Ending()
    {
        if(GameManager.Instance.Accessibilty)
        AccessibilityManager.instance.EndGame();
        if (isEnd)
        {


            manager.PlaySound(34);  //you counted by five
            yield return new WaitForSeconds(manager.Audio.clip.length);
            //manager.PlaySound ();  you counted by five
            yield return new WaitForSeconds(manager.Audio.clip.length);


        }
        else
        {
            manager.levelCounter += 1;
            manager.PlaySound(44); //  we sold all popcorn
            yield return new WaitForSeconds(manager.Audio.clip.length);
            manager.PlaySound(0); //  we sold all popcorn
            yield return new WaitForSeconds(manager.Audio.clip.length);

            Invoke("NextLevel", manager.Audio.clip.length);
        }



        PlayerPrefs.SetInt("Click", 1);



    }
    public void NextLevel()
    {
        manager.CanClick = true;
        manager.LevelFinish(manager.levelCounter);


    }




    IEnumerator LevelInitializer()
    {

        //        Debug.Log("initializing the level");

        LeftTable.GetComponent<Fade>().Fadeout = false;
        RightTable.GetComponent<Fade>().Fadeout = false;
        LeftTable.GetComponent<Fade>().FadeIn = true;
        RightTable.GetComponent<Fade>().FadeIn = true;

        progressBar.SetActive(true);
        infoButton.SetActive(true);
        CloseButton.SetActive(true);

        infoText.text = text;
        manager.PlaySound((manager.levelCounter - 1) + 20);
        yield return new WaitForSeconds(manager.Audio.clip.length);
        yield return new WaitForSeconds(1f);
        PlayerPrefs.SetInt("Click", 0);

    }

    public void shelfDisabler()
    {

        RightTable.GetComponent<Fade>().Fadeout = true;
        LeftTable.GetComponent<Fade>().Fadeout = true;


    }

    void resetTablePopcorn()
    {
        for (int i = 0; i < popcorn.Length; i++)
        {
            popcorn[i].SetActive(true);        //enabling the popcorns
            if(GameManager.Instance.Accessibilty)
            {
                if(i!=5 && i!= 0)
                popcorn[i].GetComponent<BoxCollider>().enabled = false;
            }
        }
        PlayerPrefs.SetInt("Click", 1);
    }


}
