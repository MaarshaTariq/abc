﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.InteropServices;

public class DelayToPLaySound : MonoBehaviour {
	
	public int AudioToPlay;
	GameManager Sound;
	public float sec = 1f;

	// Use this for initialization

	void OnEnable()
	{
		Sound = GameObject.Find ("GameManager").GetComponent<GameManager> ();
		StartCoroutine (wait ());
	}
	// Update is called once per frame
	void Update () {
		
	}
	IEnumerator wait()
	{
		yield return new WaitForSeconds (sec);
			Sound.Audio.clip = Sound.Sounds [AudioToPlay];
			Sound.Audio.Play ();
			if(CloseCaption.CCManager.instance)
				CloseCaption.CCManager.instance.CreateCaption(AudioToPlay, Sound.Audio.clip.length);
		
	}
}
