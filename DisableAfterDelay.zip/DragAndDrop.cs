﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragAndDrop : MonoBehaviour
{
    [HideInInspector]
    public GameObject ObjectToDrag;//reference eof the object which is goign to be dragged 
    [HideInInspector]
    public Vector3 ObjectCentre; // gameobject centre which is to be dragged
    [HideInInspector]
    public Vector3 TouchPosition; //click or touch transform position
    [HideInInspector]
    public Vector3 Offset; // vector position between touchpoint/mouse click with object centre
    [HideInInspector]
    public Vector3 NewObjectCentre; //new centre of the object during dragging
    [HideInInspector]
    public bool CanTouchOrClick = false;
    //	GameManager Manager;
    public GameObject ObjectOriginalParent;
    public GameObject ObjectParentDuringDrag;
    RaycastHit hit; //stores hit information of the object
    [HideInInspector]
    public bool CanSetParent = false;
    [HideInInspector]
    public bool DraggingMode = false;
    float Width;
    float Height;
    GameObject Selected;
    public float WidthPer = 8f;
    public float HeightPer = 8f;
    public GameObject[] ObjectRef;
    public Transform[] ObjectRefPosition;

    [HideInInspector]
    public bool CanSetPosition = true;
    [HideInInspector]
    public int PositionIndex;
    [HideInInspector]
    public bool CanResizeonClick = true;
    [HideInInspector]
    public bool CanResizeClickUp = true;
    public string[] TagNames;
    bool CanUpdateOnce = true;
    Vector3 OldPosition;
    public bool IsStockKitchen;
    /* time flies*/
    public bool IsFliesTime; // 	Arslan ( for game 13 flies time)
    public bool isCrunch;
    public bool IsFliesTimeHalf;
    /* time flies*/
    public bool isRollerCoaster; // Arslan ( for game 11 follow the path roller coaster)
    public static DragAndDrop Instance;
    bool CanTouch = true;
    bool CanParent = true;

    /// <summary>
    Rigidbody Rig;
    [HideInInspector]
    public bool XClamping;
    [HideInInspector]
    public bool YClamping;
    [HideInInspector]
    public float XClampingValueMin;
    [HideInInspector]
    public float XClampingValueMax;
    [HideInInspector]
    public float YClampingValueMin;
    [HideInInspector]
    public float YClampingValueMax;
    bool CanSetOnce = true;
    Vector3 Currentposition = new Vector3(1f, 1f, 0f);
    Vector3 Lastposition = new Vector3(0f, 0f, 0f);
    public bool isDraggin;
    public float[] resolutionRatios;
    public float[] resolutionFactor;
    /// </summary>

    public bool GobackChecker = true;
    public bool isCrunchTime = false;
    // Use this for initialization
    void Start()
    {
        Instance = this;
        //PlayerPrefs.DeleteAll();
        //Manager = GameObject.Find ("GameManager").GetComponent<GameManager> ();
        StartCoroutine(WaitToClick(4f));
        if (!isDraggin)
        {
            if (Screen.width == 1280 && Screen.height == 720)
            {
                Width = (Screen.width * 6.5f) / 1000;
                Height = (Screen.height * 6.5f) / 1000;
            }
            else if (Screen.width == 850 && Screen.height == 450)
            {
                Width = (Screen.width * 9.6f) / 1000;
                Height = (Screen.height * 9.6f) / 1000;

            }
            else
            {
                Width = (Screen.width * WidthPer) / 1000;
                Height = (Screen.height * HeightPer) / 1000;
            }
        }
        else
        {
            float width = Screen.width;
            float height = Screen.height;
            float resolutionRatio = width / height;
            float resolutionIndex = TruncateFunction.Truncate(resolutionRatio, 2);

            SetClampingValues(resolutionIndex);
            Debug.Log("Clamped");
        }
    }
    public void SetClampingValues(float resolutionRatio)
    {
        Debug.Log("----------- " + resolutionRatio);
        for (int i = 0; i < resolutionRatios.Length; i++)
        {
            if (resolutionRatio == resolutionRatios[i])
            {
                WidthPer = 20;// [i];
                HeightPer = 20;//;resolutionFactor [i];
                Width = (Screen.width * 20) / 1000;
                Height = (Screen.height * 20) / 1000;
                Debug.Log("resolutionFactor " + resolutionFactor[i]);
                break;
            }
            else
            {
                Width = (Screen.width * 8) / 1000;
                Height = (Screen.height * 8) / 1000;
                Debug.Log("else");
            }
        }
        Debug.Log("index " + resolutionRatio);
    }
    public bool CheckTag(GameObject Obj)
    {
        bool Temp = false;
        for (int i = 0; i < TagNames.Length; i++)
        {
            if (Obj.tag == TagNames[i])
                Temp = true;
        }
        return Temp;
    }

    void FixedUpdate()
    {

        //****************//
        //~Click to DRAG~//
        //***************//


        //if left mouse is clicked
        if (Input.GetMouseButtonDown(0) && CanTouchOrClick && PlayerPrefs.GetInt("Click") == 0)
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);//convert mouse click position into ray
            if (Physics.Raycast(ray, out hit))
            { // if raycast is hit by a collider
                if (CheckTag(hit.collider.gameObject))
                {
                    ObjectToDrag = hit.collider.gameObject;
                    if (CanParent)
                    {
                        CanParent = false;
                        ObjectOriginalParent = hit.collider.gameObject.transform.parent.gameObject;
                    }
                    ////
                    Rig = ObjectToDrag.GetComponent<Rigidbody>();
                    /// 

                    if (IsStockKitchen)
                    {
                        //GameManager.Instance.PlaySound (int.Parse (ObjectToDrag.gameObject.name));
                        ObjectToDrag.transform.GetChild(0).gameObject.SetActive(false);
                    }
                    if (IsFliesTimeHalf)
                    {
                        FliesControllerHalfHour.Instance.playAnalogueSound();
                    }
                    if (IsFliesTime)
                    {
                        FliesController.Instance.playAnalogueSound();
                    }
                    OldPosition = new Vector3(ObjectToDrag.transform.position.x,
                    ObjectToDrag.transform.position.y, ObjectToDrag.transform.position.z);
                    ObjectCentre = ObjectToDrag.transform.position;
                    TouchPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                    Offset = TouchPosition - ObjectCentre;
                    ObjectToDrag.transform.SetParent(ObjectParentDuringDrag.transform);
                    DraggingMode = true;
                }

            }
        }

        //if left mouse is held down
        if (Input.GetMouseButton(0) && CanTouchOrClick && PlayerPrefs.GetInt("Click") == 0)
        {
            if (DraggingMode)
            {
                if (IsFliesTime && ObjectToDrag.gameObject.tag == "Finish")
                { // Arslan ( for game 13 flies time)

                    ObjectToDrag.transform.localScale = new Vector3(0.5F, 0.5F, 0.5F);

                }
                if (IsFliesTimeHalf && ObjectToDrag.gameObject.tag == "Finish")
                { // Arslan ( for game 13 flies time)

                    ObjectToDrag.transform.localScale = new Vector3(0.5F, 0.5F, 0.5F);

                }
                // Sohaib amin 9 july//
                if (isCrunch)
                {
                    ObjectToDrag.transform.localScale = new Vector3(0.5F, 0.5F, 0.5F);
                }
                // ===== //

                TouchPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                //////
                if (XClamping)
                {
                    TouchPosition.x = Mathf.Clamp(TouchPosition.x, XClampingValueMin, XClampingValueMax);
                }
                if (YClamping)
                {
                    TouchPosition.y = Mathf.Clamp(TouchPosition.y, YClampingValueMin, YClampingValueMax);
                }
                /////

                NewObjectCentre = TouchPosition - Offset;
                //				NewObjectCentre.x = Mathf.Clamp(NewObjectCentre.x, -Width,Width);
                //				NewObjectCentre.y = Mathf.Clamp(NewObjectCentre.y, -Height, Height);

                if (isRollerCoaster)
                {
                    if (CanSetOnce)
                    {
                        Lastposition.x = NewObjectCentre.x;
                        Lastposition.y = NewObjectCentre.y;
                        CanSetOnce = false;
                        StartCoroutine(SavePosition(0.5f));
                    }
                    Currentposition.x = NewObjectCentre.x;
                    Currentposition.y = NewObjectCentre.y;


                    Rig.MovePosition(new Vector3(NewObjectCentre.x, NewObjectCentre.y, NewObjectCentre.z));


                    //for setting snap settings of draggable objects for levels
                    if (Currentposition.x > Lastposition.x && PlayerPrefs.GetString("XMov") == "Left" && Mathf.Abs(Currentposition.x - Lastposition.x) > 0.2f)
                    { //will allow only to move Left with a threshold of 0.2 while moving from Left to Right before snaping
                        SendObjectBack();
                        Debug.Log("1");
                    }
                    else if (Currentposition.x < Lastposition.x && PlayerPrefs.GetString("XMov") == "Right" && Mathf.Abs(Currentposition.x - Lastposition.x) > 0.2f)
                    { //will allow only to move Right with a threshold of 0.2 while moving from right to left before snaping
                        SendObjectBack();
                        Debug.Log("2");
                    }
                    else if (Currentposition.y < Lastposition.y && PlayerPrefs.GetString("YMov") == "Up" && Mathf.Abs(Currentposition.y - Lastposition.y) > 0.2f)
                    { //will allow only to move Up with a threshold of 0.2 while moving from Up to Down before snaping
                        SendObjectBack();
                        Debug.Log("3");
                    }
                    else if (Currentposition.y > Lastposition.y && PlayerPrefs.GetString("YMov") == "Down" && Mathf.Abs(Currentposition.y - Lastposition.y) > 0.2f)
                    { //will allow only to move Down with a threshold of 0.2 while moving from Down to Up before snaping
                        SendObjectBack();
                        Debug.Log("4");

                    }
                }
                else
                {
                    ObjectToDrag.transform.position = new Vector3(NewObjectCentre.x, NewObjectCentre.y, NewObjectCentre.z);
                }


            }
        }

        //if left click is released
        if (Input.GetMouseButtonUp(0) && DraggingMode && PlayerPrefs.GetInt("Click") == 0)
        {
            CanParent = true;
            //ObjectToDrag.transform.position = new Vector3 (OldPosition.x, OldPosition.y, OldPosition.z);

            if (!CanSetParent)
            {

                ObjectToDrag.transform.SetParent(ObjectOriginalParent.transform);
                if (!isRollerCoaster) // disable if the game "path to the rollarcoastre is enable
                    ObjectToDrag.transform.position = new Vector3(OldPosition.x, OldPosition.y, OldPosition.z);
                CanSetPosition = true;

            }
            // Sohaib amin 9 july//
            if (isCrunch)
            {
                ObjectToDrag.transform.localScale = new Vector3(1F, 1F, 01F);
            }
            // ==== //
            if (IsFliesTime && !CanSetParent)
            { // Arslan ( for game 13 flies time)
                ObjectToDrag.transform.localScale = new Vector3(1F, 1F, 1F);
            }
            if (IsFliesTimeHalf && !CanSetParent)
            { // Arslan ( for game 13 flies time)
                ObjectToDrag.transform.localScale = new Vector3(1F, 1F, 1F);
            }
            if (IsStockKitchen)
            {
                ObjectToDrag.transform.GetChild(0).gameObject.SetActive(true);
                if (PlayerPrefs.GetInt("PlaySound") == 0)
                {
                    GameManager.Instance.PlaySound(int.Parse(ObjectToDrag.gameObject.name) + 1);
                }
            }

            DraggingMode = false;

        }

        //****************//
        //~Touch to DRAG~//
        //***************//

        foreach (Touch touch in Input.touches)
        {
            switch (touch.phase)
            {
                //if finger touched
                case TouchPhase.Began:
                    if (CanTouchOrClick && CanTouch && PlayerPrefs.GetInt("Click") == 0)
                    {
                        CanTouch = false;
                        Ray ray = Camera.main.ScreenPointToRay(touch.position);//convert finger touch position into ray
                        if (Physics.Raycast(ray, out hit))
                        { // if raycast is hit by a collider

                            if (CheckTag(hit.collider.gameObject) == true)
                            {

                                if (IsStockKitchen)
                                {
                                    ObjectToDrag.transform.GetChild(0).gameObject.SetActive(false);
                                    //								GameManager.Instance.PlaySound (int.Parse (ObjectToDrag.gameObject.name));


                                }
                                if (isCrunchTime)
                                {
                                    ObjectToDrag.transform.GetChild(0).gameObject.SetActive(true);
                                }
                                ObjectToDrag = hit.collider.gameObject;
                                OldPosition = new Vector3(ObjectToDrag.transform.position.x, ObjectToDrag.transform.position.y, ObjectToDrag.transform.position.z);
                                ObjectOriginalParent = hit.collider.gameObject.transform.parent.gameObject;
                                ObjectCentre = ObjectToDrag.transform.position;
                                TouchPosition = Camera.main.ScreenToWorldPoint(touch.position);
                                Offset = TouchPosition - ObjectCentre;
                                ObjectToDrag.transform.SetParent(ObjectParentDuringDrag.transform);
                                Rig = ObjectToDrag.GetComponent<Rigidbody>();
                                DraggingMode = true;
                            }
                        }
                    }
                    break;
                //if finger dragged after touch
                case TouchPhase.Moved:
                    if (DraggingMode && CanTouchOrClick && PlayerPrefs.GetInt("Click") == 0)
                    {
                        if (IsFliesTime && ObjectToDrag.gameObject.tag == "Finish")
                        { // Arslan ( for game 13 flies time)
                            ObjectToDrag.transform.localScale = new Vector3(0.5F, 0.5F, 0.5F);
                        }
                        // Sohaib amin 9 july//
                        if (isCrunch)
                        {
                            ObjectToDrag.transform.localScale = new Vector3(0.5F, 0.5F, 0.5F);
                        }
                        // ===== //
                        if (IsFliesTimeHalf && ObjectToDrag.gameObject.tag == "Finish")
                        { // Arslan ( for game 13 flies time)
                            ObjectToDrag.transform.localScale = new Vector3(0.5F, 0.5F, 0.5F);
                        }
                        TouchPosition = Camera.main.ScreenToWorldPoint(touch.position);
                        if (XClamping)
                        {
                            TouchPosition.x = Mathf.Clamp(TouchPosition.x, XClampingValueMin, XClampingValueMax);
                        }
                        if (YClamping)
                        {
                            TouchPosition.y = Mathf.Clamp(TouchPosition.y, YClampingValueMin, YClampingValueMax);
                        }
                        /////
                        NewObjectCentre = TouchPosition - Offset;
                        //					NewObjectCentre.x = Mathf.Clamp(NewObjectCentre.x, -Width,Width);
                        //					NewObjectCentre.y = Mathf.Clamp(NewObjectCentre.y, -Height, Height);
                        if (isRollerCoaster)
                        {
                            if (CanSetOnce)
                            {
                                Lastposition.x = NewObjectCentre.x;
                                Lastposition.y = NewObjectCentre.y;
                                CanSetOnce = false;
                                StartCoroutine(SavePosition(0.5f));
                            }
                            Currentposition.x = NewObjectCentre.x;
                            Currentposition.y = NewObjectCentre.y;


                            Rig.MovePosition(new Vector3(NewObjectCentre.x, NewObjectCentre.y, NewObjectCentre.z));


                            //for setting snap settings of draggable objects for levels
                            if (Currentposition.x > Lastposition.x && PlayerPrefs.GetString("XMov") == "Left" && Mathf.Abs(Currentposition.x - Lastposition.x) > 0.3f)
                            { //will allow only to move Left with a threshold of 0.2 while moving from Left to Right before snaping
                                SendObjectBack();
                                Debug.Log("1");

                            }
                            else if (Currentposition.x < Lastposition.x && PlayerPrefs.GetString("XMov") == "Right" && Mathf.Abs(Currentposition.x - Lastposition.x) > 0.3f)
                            { //will allow only to move Right with a threshold of 0.2 while moving from right to left before snaping
                                SendObjectBack();
                                Debug.Log("2");

                            }
                            else if (Currentposition.y < Lastposition.y && PlayerPrefs.GetString("YMov") == "Up" && Mathf.Abs(Currentposition.y - Lastposition.y) > 0.3f)
                            { //will allow only to move Up with a threshold of 0.2 while moving from Up to Down before snaping
                                SendObjectBack();
                                Debug.Log("3");

                            }
                            else if (Currentposition.y > Lastposition.y && PlayerPrefs.GetString("YMov") == "Down" && Mathf.Abs(Currentposition.y - Lastposition.y) > 0.3f)
                            { //will allow only to move Down with a threshold of 0.2 while moving from Down to Up before snaping
                                SendObjectBack();
                                Debug.Log("4");

                            }
                        }
                        else
                        {
                            ObjectToDrag.transform.position = new Vector3(NewObjectCentre.x, NewObjectCentre.y, NewObjectCentre.z);
                        }
                    }
                    break;
                //if finger removed after finising touch
                case TouchPhase.Ended:
                    CanTouch = true;

                    if (DraggingMode && PlayerPrefs.GetInt("Click") == 0)
                    {

                        if (IsStockKitchen)
                        {
                            if (PlayerPrefs.GetInt("PlaySound") == 0)
                            {
                                GameManager.Instance.PlaySound(int.Parse(ObjectToDrag.gameObject.name) + 1);
                            }

                        }
                        if (isCrunchTime)
                        {
                            ObjectToDrag.transform.GetChild(0).gameObject.SetActive(false);
                        }
                        // Sohaib amin 9 july//
                        if (isCrunch)
                        {
                            ObjectToDrag.transform.localScale = new Vector3(1F, 1F, 01F);
                        }
                        // ==== //
                        if (IsFliesTime)
                        { // Arslan ( for game 13 flies time)
                            ObjectToDrag.transform.localScale = new Vector3(1F, 1F, 1F);
                        }
                        if (IsFliesTimeHalf)
                        { // Arslan ( for game 13 flies time)
                            ObjectToDrag.transform.localScale = new Vector3(1F, 1F, 1F);
                        }
                        ObjectToDrag.transform.GetChild(0).gameObject.SetActive(true);
                        if (!CanSetParent)
                        {
                            ObjectToDrag.transform.SetParent(ObjectOriginalParent.transform);
                            if (!isRollerCoaster) // disable if the game "path to the rollarcoastre is enable
                                ObjectToDrag.transform.position = new Vector3(OldPosition.x, OldPosition.y, OldPosition.z);
                            CanSetPosition = true;

                        }
                        DraggingMode = false;
                    }
                    break;
            }

        }
    }

    public IEnumerator WaitToClick(float sec)
    {
        yield return new WaitForSeconds(sec);
        CanTouchOrClick = true;

    }
    IEnumerator SavePosition(float Sec)
    {
        yield return new WaitForSeconds(Sec);
        CanSetOnce = true;

    }
    public void SendObjectBack()
    {

        if (GobackChecker)
        {

            Debug.Log("go back");
            PlayerPrefs.SetString("GoBack75", "Yes");
            if (TrailHandler.Instance != null)// for roller coaster
                TrailHandler.Instance.ResetTrail();
            if (TriggerEnterZoo.Instance != null)// for roller coaster
                TriggerEnterZoo.Instance.SendBack(ObjectToDrag.transform.GetChild(0).gameObject);
            DraggingMode = false;
            Currentposition = new Vector3(1f, 1f, 0f);
            Lastposition = new Vector3(0f, 0f, 0f);
            PlayerPrefs.SetString("SoundHeard", "No");
            GameManager.Instance.PlaySound(4); // wrong

            if (CoasterLevelController.Instance != null) // for roller coaster
                CoasterLevelController.Instance.enablePointCollider();
        }
    }
}
