﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoreProgressBar : MonoBehaviour {
	public GameObject[] Bars;
	public string ProgressString = "Progress";
	public int LevelNumbers;
	[HideInInspector]
	public float Temp;
	public static CoreProgressBar Instance;

	// Use this for initialization
	void Start () {
		PlayerPrefs.SetInt (ProgressString, 0);
		Instance = this;
	//	PlayerPrefs.SetInt (ProgressString, 1);
		Temp = Bars.Length / LevelNumbers;
	}

	// Update is called once per frame
	public void ProgressInfo()
	{
		for (int i = 0; i < Temp*PlayerPrefs.GetInt(ProgressString); i++) {

				Bars [i].SetActive (true);
			}
	}

}
