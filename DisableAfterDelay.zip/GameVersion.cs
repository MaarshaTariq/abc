﻿
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Text))]
public class GameVersion : MonoBehaviour {

	void Awake () {
		GetComponent<Text>().text = "v " + Constants.version;
	}
	
}
