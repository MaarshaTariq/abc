﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Constants 
{
	public static string version = "1.4"; 
}
