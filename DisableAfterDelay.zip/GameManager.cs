﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Runtime.InteropServices;
using System;

public class GameManager : MonoBehaviour
{

    [DllImport("__Internal")]
    private static extern void _OnGameStarted();
    [DllImport("__Internal")]
    private static extern void _OnGameStopped();
    [DllImport("__Internal")]
    private static extern void _ExitFullScreen();
    [Header("Use these to dkeep track of GameNumber and Version")]
    public int gameNumber;
    public float versionNumber;
    public bool unityLogger;
    ///<summary>Only for games have more than 1 scenes</summary>
    public int sceneNumber = 1;
    public GameObject[] Panels_List;
    bool CanClickPlayOnce = true;
    public AudioClip[] Sounds;
    [HideInInspector]
    public AudioSource Audio;
    Fade[] mode;
    public GameObject Pause_Pnl;
    public float DelayToStartGame;
    public int SoundToPlayStart;
    [HideInInspector]
    public bool CanClickAgain = true;
    public string SceneName;
    public float SecondsToDelayAgain = 1.2f;
    [HideInInspector]
    public bool CanClick = true;

    [HideInInspector]
    public int levelCounter = 1;
    public bool IsErrands = false;
    public bool IsCarWash = false;
	public bool is58;
    public bool isExternalDone = false;
	public GameObject parent;
    private bool accessibilty = false;

    public bool Accessibilty
    {
        set
        {
            Debug.Log("Set Accessibilty: " + accessibilty + " -> " + value);
            accessibilty = value;
        }
        get
        {
            Debug.Log("Get Accessibilty: " + accessibilty);
            return accessibilty;
        }
    }


    public static GameManager Instance;
    public GameObject AccessibiltyObject;
    public float gameSpeed = 1;
    public bool changeGameSpeed;
    public int index97 = 1;
    public int pauseStopPressedCount;

    void Awake()
    {
        Instance = this;
    }

    void OnEnable()
    {
        //Turning of Unity Debugger for removing logs.
        print("Game Number: " + gameNumber);
        print("Version Number: " + versionNumber);
        Debug.unityLogger.logEnabled = unityLogger;
#if !UNITY_EDITOR
        _OnGameStarted();
#endif

        PlayerPrefs.SetInt("Click", 0);
    }
    // Use this for initialization
    void Start()
    {
        if (GameNumber(92) && Accessibilty)
            AccessibiltyObject = FindObjectOfType<AccessibilityManager>().gameObject;
        //		Debug.Log("game manager is started ---  ");
        pauseStopPressedCount = 0;
        PlayerPrefs.SetInt("SetPrefernce", 0);
        PlayerPrefs.SetInt("ObjectPlaced", 0);  //for count reset  of rocket part capture in build it rocket model
        PlayerPrefs.SetString("HAIR", "NULL");
        PlayerPrefs.SetString("clickable", "true");
        PlayerPrefs.SetInt("Collected", 0);
        PlayerPrefs.SetInt("Click", 0);
        PlayerPrefs.SetInt("IND", 0);
        //PlayerPrefs.SetString ("clickable","true");
        Audio = GetComponent<AudioSource>();
        // used to keep track of level visited for random gameplay

        mode = new Fade[Panels_List.Length]; // initailizing the mode with repect to the level of panel's length
		if (!is58) {
			for (int i = 0; i < Panels_List.Length; i++) {
				mode [i] = Panels_List [i].GetComponent<Fade> ();
			}
		}

    }

    void Update()
    {
        if (changeGameSpeed)
        {
            changeGameSpeed = false;
#if UNITY_EDITOR //for testing purposes in editor
            Time.timeScale = gameSpeed;
#endif
        }
    }

    public void PlaySound(int ind)  //play sound function with both unity audio source and html audio play
    {
        Audio.clip = Sounds[ind];
        Audio.Play();
        Debug.Log("GameManager->PlaySound(" + ind + ")");

        if (!Accessibilty)
            return;

        if (TextToSpeech.ins && !GameNumber(92))
            TextToSpeech.ins.StopAudio();
        if (CloseCaption.CCManager.instance)
            CloseCaption.CCManager.instance.CreateCaptionsWithSubSentences(ind, Audio.clip.length);
    }
    /*
     * 
     * Starting function of every game which is called by evey game's play button
     * 
     * 
     * 
     * */
    public void FadeOnClickBtn(int fadeOn)      //this is the function which will be called when play button and each next button at end of level is clicked 
    {
        if (fadeOn == 0 && CanClickPlayOnce)
        {
            PlaySound(SoundToPlayStart);
            CanClickPlayOnce = false;
            StartCoroutine(WaitToDisable(DelayToStartGame, fadeOn));
        }
        else if (fadeOn != 0)
        {
            //			OnTriggerenter triggerHandler = GameObject.FindGameObjectWithTag ("Collector").GetComponent<OnTriggerenter> ();
            StartCoroutine(WaitToDisable(6.85f, fadeOn));
        }
    }
    void OnOk()
    {
        PlayerPrefs.SetString("CanOk", "true");
    }
    public void OnButtonClicked(string BtnName)  //called when UI buttons are preesed
    {
        if (BtnName == "Pause")
        {
            Debug.Log("Pause");
            // condition used to check that the pause menu donot opens after user clicked the right button
            if (PlayerPrefs.GetString("clickable").Equals("true") || PlayerPrefs.GetInt("Click") == 0)
            {
                if (GameNumber(97))
                {
                    print("Button non interactable");
                    Panels_List[index97].GetComponent<GamePlay97>().NewButton.interactable = false;
                }
                Time.timeScale = 0f;
                if (IsCarWash)
                {
                    PlayerPrefs.SetInt("Click", 1);
                    PlayerPrefs.SetString("clickable", "false");
                }
                if (gameNumber == 97)
                {
                    PlayerPrefs.SetString("CanOk", "false");
                }
                Pause_Pnl.SetActive(true);
            }
        }
        else if (BtnName == "Again" && CanClickAgain)
        {
            PlayerPrefs.SetInt("FullScreen", 0);

            Time.timeScale = 1f;
            CanClickAgain = false;
            StartCoroutine(LoadScene());

        }
        else if (BtnName == "Stop")
        {
            Debug.Log("stop");
            if (Screen.fullScreen)
            {
                _ExitFullScreen();
                Screen.fullScreen = !Screen.fullScreen;
            }

            if (!External.Instance.Preview)
                StartCoroutine(CallStop());
            else
            {
                Debug.Log("stoped");
                _OnGameStopped();
                // _OnGameStopped();
            }
        }
        else if (BtnName == "FullScrren")
        {
            Debug.Log("Full Screen");
            if (DragAndDrop.Instance != null && DragAndDrop.Instance.isRollerCoaster)
            {
                DragAndDrop.Instance.GobackChecker = false;
            }
            if (Screen.fullScreen)
            {
                _ExitFullScreen();
                Screen.fullScreen = false;
                FullScreenBtn.Instance.IMG.sprite = FullScreenBtn.Instance.FullScreenIMG[0];
            }
            else
            {
                FullScreenBtn.Instance.IMG.sprite = FullScreenBtn.Instance.FullScreenIMG[1];
                Screen.fullScreen = true;
            }
            if (DragAndDrop.Instance != null && DragAndDrop.Instance.isRollerCoaster)
            {
                StartCoroutine(waitTOEnableColliders());
            }
        }
        else if (BtnName == "PausePlay")
        {
            if (EventController.instance != null && !External.Instance.Preview)
            {
                // EventController.instance.CountScreenInteractionWithoutCheck();
                EventController.instance.DecreaseCountForPlayPause();
            }
            if (gameNumber == 97)
            {
                Invoke("OnOk", 0.8f);
            }
            if (GameNumber(97))
            {
                print("Button interactable");
                Panels_List[index97].GetComponent<GamePlay97>().NewButton.interactable = true;
            }
            Time.timeScale = 1f;
            Pause_Pnl.SetActive(false);
            if (IsCarWash)
            {
                PlayerPrefs.SetInt("Click", 0);
                PlayerPrefs.SetString("clickable", "true");
            }

            if (AccessibilityManager.instance != null)
            {
                AccessibilityManager.instance.ShowPausePanel = true;
                AccessibilityManager.instance.gameWasPaused = true;
            }
        }
        else if (BtnName == "PauseStop")
        {
            if (pauseStopPressedCount < 1)
                pauseStopPressedCount++;
            else return;

            if (EventController.instance != null && !External.Instance.Preview)
            {
                if (Accessibilty)
                {
                    EventController.instance.DecreaseCountForPlayPause();
                }
                EventController.instance.currentGamePercentage();
            }

            Time.timeScale = 1f;
            if (AccessibilityManager.instance != null)
                AccessibilityManager.instance.LastCheck = false;

            Debug.Log("Ending the game");

            if (Screen.fullScreen)
            {
                _ExitFullScreen();
                Screen.fullScreen = !Screen.fullScreen;
            }

            if (!External.Instance.Preview)
                StartCoroutine(CallStop());
            else
                _OnGameStopped();

            // _OnGameStopped();
        }
    }

    IEnumerator WaitToDisable(float Sec, int FadeOn)
    {
        yield return new WaitForSeconds(Sec);
        if (FadeOn == 0)
		{if(!is58)
            mode[0].Fadeout = true;
			if (is58) {
				//Destroy (Panels_List [0].gameObject);
				Debug.Log("start loading");
				GameObject obj = Resources.Load<GameObject> ("58/Gameplay1");
				Debug.Log("end loading");	
				Instantiate (obj, parent.transform);
				obj.gameObject.transform.SetAsFirstSibling ();
				parent.gameObject.transform.GetChild (4).gameObject.transform.SetSiblingIndex (1);
				obj.SetActive (true);
				Debug.Log("SetActive loading");	
				Debug.Log (obj.gameObject.transform.GetSiblingIndex());
				Panels_List [1] = obj;
			}

            yield return new WaitForSeconds(1.2f);
            Panels_List[FadeOn].SetActive(false);
            if (IsErrands)
            {
                PlayerPrefs.SetInt("Level", 1);
                IsErrands = false;
            }

            Panels_List[FadeOn + 1].SetActive(true);
        }
    }

    public IEnumerator NextLevel(int Ind, float Sec)
    {


        yield return new WaitForSeconds(Sec);
        CanClick = true;
        for (int i = 0; i < Panels_List.Length; i++)
        {
            if (i == Ind)
            {
                Panels_List[i].SetActive(true);
            }
            else
            {

                Panels_List[i].SetActive(false);
            }
        }


    }

    public IEnumerator LoadScene()
    {

        yield return new WaitForSeconds(0.1f);
        if (Screen.fullScreen)
        {
            _ExitFullScreen();
            Screen.fullScreen = !Screen.fullScreen;
        }

		GC.Collect();
		GC.WaitForPendingFinalizers();
		//GL.Clear ();
		Resources.UnloadUnusedAssets (); 
        SceneManager.LoadScene(SceneName, LoadSceneMode.Single);


    }
    IEnumerator waitTOEnableColliders()
    {
        yield return new WaitForSeconds(2f);
        DragAndDrop.Instance.GobackChecker = true;

    }
    public IEnumerator SecondsToDelay()
    {
        yield return new WaitForSeconds(SecondsToDelayAgain);
        CanClickAgain = true;
    }

    public void LevelFinish(int ind)
    {

        if (CanClick)
        {
            index97 = ind;
            CanClick = false;
            Fade Mode = GameObject.FindGameObjectWithTag("GamePlay").GetComponent<Fade>();
            Mode.Fadeout = true;
            StartCoroutine(NextLevel(ind, 1.1f));
        }
    }

    public IEnumerator CallStop()
    {
        yield return new WaitUntil(() => RestAPIHandler.Instance.UploadedSuccessfully == true);
        _OnGameStopped();
    }

    public bool GameNumber(params int[] gameNumbers)
    {
        //Debug.Log("GameManager->GameNumber() "+gameNumber);

        for (int i = 0; i < gameNumbers.Length; i++)
        {
            if (gameNumbers[i] == gameNumber)
                return true;
        }
        return false;
    }

    public bool SceneNumber(params int[] SceneNumbers)
    {
        // Debug.Log("GameManager->GameNumber()");

        for (int i = 0; i < SceneNumbers.Length; i++)
        {
            if (SceneNumbers[i] == sceneNumber)
                return true;
        }

        return false;
    }
}
