﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.InteropServices;
using UnityEngine.UI;

public class InfoBtnHandler : MonoBehaviour {

	public Animator InfoBtn;
	public bool Game70;
	public GameObject closeWin;
	public bool game79;
	bool CanPlayInfoSound=false;
	GameManager Manager;
	public DragAndDrop mode;
	public float WaitToPlay;
	public float WaitToClick=4.8f;
	public bool isDragDrop = false;
	public bool isBigBox = false; // arslan
public int BigBoxindex = 31; // arslan
public int secondSoundIndex = 10;
	public static InfoBtnHandler instance;
	// Use this for initialization
	void Start () {
		PlayerPrefs.SetString ("clickable","false");
		instance = this;
		Manager = GameObject.Find ("GameManager").GetComponent<GameManager> ();
		StartCoroutine (WaitToPlaySound (WaitToPlay));
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	//for opening and closing info button
	public void OpenInfo(int ind)
	{
		Debug.Log("InfoBtnHandler->OpenInfo()");
		if (PlayerPrefs.GetInt ("Click") == 0 ||PlayerPrefs.GetString ("clickable") == "true") {
			PlayerPrefs.SetString ("clickable", "false");
			PlayerPrefs.SetInt ("Click", 1);
			if(game79)
				closeWin.SetActive (true);
			if ((CanPlayInfoSound)) {
		
				if (ind != null) {
					if (!GameManager.Instance.Accessibilty && Game70) {
						StartCoroutine(CorrectSoundPlayer.PlaySound ());
					}
					if (isBigBox) {
						StartCoroutine (Wait());

					} else {
						Manager.Audio.clip = Manager.Sounds [ind];
						Manager.Audio.Play ();
						if(CloseCaption.CCManager.instance)
							CloseCaption.CCManager.instance.CreateCaption(ind, Manager.Audio.clip.length);
					}


				}
				CanPlayInfoSound = false;
				StartCoroutine (WaitToPlaySound (WaitToPlay));

				if (isDragDrop) {
					mode.CanTouchOrClick = false;
					StartCoroutine (mode.WaitToClick (WaitToClick));
				}

			}

			InfoBtn.gameObject.SetActive (true);
			InfoBtn.SetBool ("CloseInfo", false);
			InfoBtn.SetBool ("OpenInfo", true);
		}
	}

	public void PlayInfo(int ind)
	{

			PlayerPrefs.SetString ("clickable", "false");
			PlayerPrefs.SetInt ("Click", 1);

			if ((CanPlayInfoSound)) {

				if (ind != null) {
					if (!GameManager.Instance.Accessibilty && Game70) {
						StartCoroutine(CorrectSoundPlayer.PlaySound ());
					}
				}
				CanPlayInfoSound = false;
				StartCoroutine (WaitToPlaySound (WaitToPlay));
			}
	}



	public void CloseInfo()
	{
		PlayerPrefs.SetString ("clickable","true");
	   // PlayerPrefs.SetInt ("Click", 0);
		InfoBtn.SetBool ("CloseInfo", true);
		InfoBtn.SetBool ("OpenInfo", false);
		StartCoroutine (WaitSec ());


	}
	IEnumerator Wait()
	{
		Manager.Audio.clip = Manager.Sounds [BigBoxindex];
		
		if(Manager.Audio.clip!= null){

		Manager.Audio.Play ();
		if(CloseCaption.CCManager.instance)
			CloseCaption.CCManager.instance.CreateCaption(BigBoxindex, Manager.Audio.clip.length);
		yield return new WaitForSeconds (Manager.Audio.clip.length);

		}
		Manager.Audio.clip = Manager.Sounds [(Manager.levelCounter-1)+secondSoundIndex];
		Manager.Audio.Play ();
		if(CloseCaption.CCManager.instance)
			CloseCaption.CCManager.instance.CreateCaption((Manager.levelCounter-1)+secondSoundIndex, Manager.Audio.clip.length);

	}
	IEnumerator WaitToPlaySound(float sec)
	{
        // Debug.Log("InfoBtnHandler->WaitToPlaySound(" + sec + ")");
		yield return new WaitForSeconds (sec);
		CanPlayInfoSound = true;
		PlayerPrefs.SetInt ("Click", 0);
		// Debug.Log("InfoBtnHandler->WaitToPlaySound(" + PlayerPrefs.GetInt ("Click") + ")");
		
	}
	IEnumerator WaitSec()
	{
		yield return new WaitForSeconds (0.5f);
		InfoBtn.gameObject.SetActive (false);

	}
}
