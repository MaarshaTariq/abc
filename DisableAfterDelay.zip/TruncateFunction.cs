﻿using UnityEngine;
using System.Collections;
using System;

public static class TruncateFunction
{
	public static float Truncate(this float value, int digits)
	{
		double mult = Math.Pow(10.0, digits);
		double result = Math.Truncate( mult * value ) / mult;
		return (float) result;
	}
}
